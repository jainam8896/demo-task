const express = require("express");
const router = express.Router();
const rules = require("../utils/validations/user/validation");
const rulesOtp = require("../utils/validations/otp/validation");
const validate = require("../middlewares/validate");
const auth = require("../middlewares/auth");
const tokenAuth = require("../middlewares/token");
const userRegistration = require("../controllers/authentication/signup");
const userLogin = require("../controllers/authentication/login");
const changePassword = require("../controllers/authentication/changePassword");
const forgetPassword = require("../controllers/authentication/forgetPassword");
const resetPassword = require("../controllers/authentication/resetPassword");
const upload = require("../helper/userimageupload");
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler");
const verifyOtp = require("../controllers/authentication/verifyOtp");

router.post(
  "/signup",
  upload.single("profileimage"),
  validate(rules.registerValidator),
  asyncErrorHandler(async function _userRegistration(req, res, next) {
    const data = await userRegistration(req.body, req.file);
    return res.success("User Registration Successfully", data, "success", 200);
  })
);

router.post("/login", validate(rules.loginValidator), userLogin);

router.post(
  "/changePassword",
  validate(rules.changePasswordValidator),
  auth,
  changePassword
);

router.post(
  "/forgetpassword",
  validate(rules.forgetPasswordValidator),
  forgetPassword
);

router.get(
  "/resetpassword",
  validate(rules.resetPasswordValidator),
  resetPassword
);

router.post(
  "/verify-otp",
  validate(rulesOtp.otpValidation),
  tokenAuth,
  verifyOtp
);

module.exports = router;
