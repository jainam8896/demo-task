const Review = require("../../models/Reviews");
const CustomError = require("../../utils/errors/CustomError");

const updateReview = async (req, res) => {
  const { id } = req.params;
  const { reviews } = req.body;
  const updateReview = await Review.findByIdAndUpdate(id, {
    $set: {
      reviews: reviews,
      userId: req.user._id,
      productId: req.params.productId,
    },
  });
  if (!updateReview){
    return next(new CustomError("Review Not Found", 404));
  }
  const newReview = await updateReview.save();
  return res.send({ status: "success", message: "Review Updated successfully" });
};

module.exports = updateReview;
