const Product = require("../../models/Product");
const CustomError = require("../../utils/errors/CustomError");

//Display Product By Id
const getProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);
    if (!product) {
      return next(new CustomError("Product Not Found", 404));
    }
    res.json(product);
  } catch (error) {
    res.json(error);
  }
};

module.exports = getProduct;
