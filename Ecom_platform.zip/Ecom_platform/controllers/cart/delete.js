const { log } = require("console");
const Cart = require("../../models/Cart");
const CustomError = require("../../utils/errors/CustomError");

const removeCart = async (req, res, next) => {
  let userId = req.user._id;
  let { productId } = req.params;

  try {
    let cart = await Cart.findOne({ userId: userId });
    if (!cart) {
      return next(new CustomError("Cart not found for this user", 404));
    }
    let item = cart.products.findIndex((p) => p.productId == productId);
    if (item > -1) {
      cart.products.splice(item, 1);
      cart = await cart.save();
      return res.status(200).send({ status: true, updatedCart: cart });
    }
    return next(new CustomError("Item does not exist in cart", 404));
  } catch (error) {
    log("error", error);
    res.status(500).send("Something went wrong");
  }
};

module.exports = removeCart;
