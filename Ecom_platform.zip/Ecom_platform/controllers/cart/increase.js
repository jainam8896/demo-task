const Cart = require("../../models/Cart");
const CustomError = require("../../utils/errors/CustomError");

const increaseQty = async (req, res, next) => {
  const userId = req.user._id;
  let { productId } = req.params;

  try {
    let cart = await Cart.findOne({ userId: userId });
    if (!cart)
      return next(new CustomError("Cart not found for this user", 404));

    let item = cart.products.findIndex((p) => p.productId == productId);

    if (item > -1) {
      let productItem = cart.products[item];
      if (productItem.qty > 0) {
        productItem.qty += 1;
        cart.products[item] = productItem;
      } else {
        cart.products.splice(item, 1);
        console.log("Cart product", cart.products);
      }
      cart = await cart.save();
      return res.status(200).send({ status: true, updatedCart: cart });
    }
    return next(new CustomError("Item does not exist in cart", 404));
  } catch (error) {
    console.log("error", error);
    res.status(500).send("Something went wrong");
  }
};

module.exports = increaseQty;
