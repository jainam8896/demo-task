const Category = require("../../models/Category");
const { validationResult } = require("express-validator");
const CustomError = require("../../utils/errors/CustomError");

//Create user
const createCategory = async (req, res, next) => {
  try {
    const { name, parentId } = req.body;
    const category = await Category.findOne({ name: name });
    if (category) {
      return next(new CustomError("Category Already Exists", 404));
    }
    const newCategory = new Category({
      name: name,
      parentId: parentId,
    });
    await newCategory.save();
    res
      .status(200)
      .send({ status: "success", message: "Category Added Successfully", newCategory });
  } catch (error) {
    res.json(error);
  }
};

module.exports = createCategory;
