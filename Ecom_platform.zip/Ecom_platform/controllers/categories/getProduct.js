const Category = require("../../models/Category");
const CustomError = require("../../utils/errors/CustomError");

const getProduct = async (req, res, next) => {
  try {
    const { categoryId } = req.params;
    const category = await Category.findById(categoryId)
      .lean()
      .populate("products");
    if (!category) {
      return next(new CustomError("Category not found", 401));
    }
    res.json({ category });
  } catch (error) {
    console.log("Error", error);
    return next(new CustomError("Internal Server Error", 500));
  }
};

module.exports = getProduct;
