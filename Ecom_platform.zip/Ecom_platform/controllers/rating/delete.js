const Rating = require("../../models/Rating");
const CustomError = require("../../utils/errors/CustomError");

const deleteRating = async (req, res, next) => {
  const { id } = req.params;
  const rating = await Rating.findByIdAndDelete(id);
  if (!rating){
    return next(new CustomError("Rating Not Found", 404));
  } 
  return res.send({ status: "success", message: "Rating deleted successfully" });
};

module.exports = deleteRating;
