const Rating = require("../../models/Rating");
const CustomError = require("../../utils/errors/CustomError");

const updateRating = async (req, res) => {
  const { id } = req.params;
  const { ratings } = req.body;
  const updateRating = await Rating.findByIdAndUpdate(id, {
    $set: {
      ratings: ratings,
      userId: req.user._id,
      productId: req.params.productId,
    },
  });
  if (!updateRating) {
    return next(new CustomError("Rating Not Found", 404));
  }
  const newRating = await updateRating.save();
  return res.send({
    status: "success",
    message: "Rating Updated successfully",
    newRating,
  });
};

module.exports = updateRating;
