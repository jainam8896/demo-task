const { log } = require("console");
const Otp = require("../../models/Otp");
const Token = require("../../models/Token");
const CustomError = require("../../utils/errors/CustomError");
const jwt = require("jsonwebtoken");

const verifyOtp = async (req, res, next) => {
  try {
    const { otp } = req.body;
    log("Request Body Otp:- ", otp);

    const tokenData = req.token;
    log("Request Token:- ", tokenData);

    log("user Id:- ", req.user._id);

    const otpData = await Otp.findOne({
      userId: req.user._id,
      otp: otp,
    });

    log("Otp Data:- ", otpData);

    if (!otpData) {
      return next(
        new CustomError("Inccorect Otp, Please Enter Valid OTP", 401)
      );
    }

    await Otp.findByIdAndDelete({ _id: otpData._id });
    log("Otp Id:- ", otpData._id);

    await Token.findByIdAndDelete({ _id: tokenData._id });
    log("Token Id:- ", tokenData._id);

    const LoginToken = jwt.sign(
      { _id: req.user._id },
      process.env.JWT_SECRET_KEY,
      { expiresIn: "20m" }
    );

    const accessToken = new Token({
      userId: req.user._id,
      type: "ACCESS_TOKEN",
      token: LoginToken,
    });

    await accessToken.save();
    log("Access Token:-", accessToken);

    return res
      .status(200)
      .json({ status: "success", message: "Login success", accessToken });
  } catch (error) {
    log("Error", error);
  }
};

module.exports = verifyOtp;
