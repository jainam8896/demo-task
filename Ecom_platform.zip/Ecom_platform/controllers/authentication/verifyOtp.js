const { log } = require("console");
const Otp = require("../../models/Otp");
const Token = require("../../models/Token");
const CustomError = require("../../utils/errors/CustomError");
const crypto = require("crypto");

const verifyOtp = async (req, res, next) => {
  try {
    const { otp } = req.body;
    const tokenData = req.token;

    const otpData = await Otp.findOne({
      userId: req.user._id,
      otp: otp,
    });

    if (!otpData) {
      return next(
        new CustomError("Inccorect Otp, Please Enter Valid OTP", 401)
      );
    }

    //Once Otp and Token Verify Then Delete
    await otpData.deleteOne();
    await tokenData.deleteOne();

    //Genrate Access Token
    const LoginToken = crypto.randomUUID();

    const accessToken = new Token({
      userId: req.user._id,
      type: "ACCESS_TOKEN",
      token: LoginToken,
    });

    await accessToken.save();
    return res
      .status(200)
      .json({ status: "success", message: "Login success", accessToken });
      
  } catch (error) {
    log("Error", error);
  }
};

module.exports = verifyOtp;
