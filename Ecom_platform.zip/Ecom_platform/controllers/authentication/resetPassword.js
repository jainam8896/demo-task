const { log } = require("console");
const User = require("../../models/User");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const CustomError = require("../../utils/errors/CustomError");

const resetPassword = async (req, res, next) => {
  const token = req.query.token;
  const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
  const { newPassword } = req.body;
  const userData = await User.findById(_id);
  if (!userData) {
    return next(new CustomError("This Link Is not valid", 404));
  }
  const hashPassword = bcrypt.hashSync(newPassword, 10);
  userData.password = hashPassword;
  userData.token = null;
  await userData.save();
  log(hashPassword);
  res.status(200).json({ message: "Your Password Updated Successfully" });
};

module.exports = resetPassword;
