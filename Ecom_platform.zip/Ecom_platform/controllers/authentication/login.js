const { log } = require("console");
const User = require("../../models/User");
const Otp = require("../../models/Otp");
const Token = require("../../models/Token");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const CustomError = require("../../utils/errors/CustomError");
const moment = require("moment");
const transporter = require("../../helper/sendOtpEmail");

const userLogin = async (req, res, next) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email: email }).select([
      "password",
      "attempts",
      "lockeTime",
    ]);
    if (!user) {
      return next(new CustomError("User Not Register", 404));
    }
    const { lockeTime, attempts } = user;
    if (lockeTime > moment()) {
      const remaningTime = moment(lockeTime).diff(moment(), "minutes");
      return next(
        new CustomError(
          `Your Account Has been Lock. Please try again after ${remaningTime} minutes.`,
          403
        )
      );
    }
    const match = bcrypt.compareSync(password, user.password);
    if (!match) {
      //Lock user for 1 hour after 3 unsuccessfull login attempts with wrong password
      user.attempts += 1;
      await user.save();
      if (attempts >= 2) {
        user.lockeTime = moment().add(1, "hour");
        await User.updateOne(
          { email },
          { $set: { attempts: 0 }, lockeTime: lockeTime }
        );
        return next(new CustomError("your Account lock for 1 hr", 401));
      }
      return next(new CustomError("Email Or Password doesn't match", 401));
    }
    user.attempts = 0;
    user.lockeTime = null;
    await user.save();
    const token = jwt.sign({ _id: user._id }, process.env.JWT_SECRET_KEY, {
      expiresIn: "20m",
    });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    log("otp", otp);

    await Otp.findOneAndUpdate(
      { userId: user._id },
      { otp: otp },
      { new: true, upsert: true }
    );

    await Token.findOneAndUpdate(
      { userId: user._id, type: "2FA_TOKEN" },
      { token: token },
      { new: true, upsert: true }
    );

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Your OTP",
      html: `Your Otp is ${otp}`,
    });

    return res.status(200).json({
      status: "success",
      message: "Otp has been send, Please Check Your Mail",
      token: token,
    });
  } catch (error) {
    log(error);
    return next(new CustomError("Unable to Login", 500));
  }
};

module.exports = userLogin;
