const { log } = require("console");
const User = require("../../models/User");
const bcrypt = require("bcrypt");
const CustomError = require("../../utils/errors/CustomError");

//User signup
async function userRegistration(params, image, next) {
  const { name, email, age, password, address } = params;
  try {
    const user = await User.findOne({ email: email });
    if (user) {
      return next(new CustomError("Email Already Exists", 404));
    }
    const hasPassword = bcrypt.hashSync(password, 10);
    const userDoc = new User({
      name: name,
      email: email,
      age: age,
      password: hasPassword,
      address: address,
      profileimage: image.filename,
    });
    await userDoc.save();
    return userDoc;
  } catch (error) {
    log(error);
    return next(new CustomError("Unable to Register", 500));
  }
}

module.exports = userRegistration;

