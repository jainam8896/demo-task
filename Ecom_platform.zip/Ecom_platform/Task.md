## Mongoose/MongoDB Queries
## CoreJS concepts
## String Method
## Array Method
## Pagination
## add to cart  [DONE]
## Lock user for 1 hour after 3 unsuccessfull login attempts with wrong password []
## user can post reviews and rate the product
## Learn about moment library (https://momentjs.com/)
## create and API which accept categoryID as params
    -   fetch category
    -   fetch products of that category

{
  "name": "man",
  "parentId": null,
  "createdAt": {
    "$date": "2024-05-06T08:59:37.255Z"
  },
  "updatedAt": {
    "$date": "2024-05-06T08:59:37.255Z"
  },
  products: [
    {},
    {},
    {},
  ]
}
## Send OTP if credentials are correct, once OTP is verified then only all API's are accesible


