const mongoose = require("mongoose");

const schema = new mongoose.Schema(
  {
    name:{
      type: String,
      required: true,
    },
    parentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

schema.virtual("products", {
  ref: "product",
  foreignField: "categoryId",
  localField: "_id",
});

const Category = mongoose.model("Category", schema);
module.exports = Category;
