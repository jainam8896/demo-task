const mongoose = require("mongoose");

const schema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    token: {
      type: String,
    },
    type: {
      type: String,
    },
  },
  { timestamps: true }
);
const Token = mongoose.model("token", schema);
module.exports = Token;
