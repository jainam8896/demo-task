const { body } = require("express-validator");

const otpValidation = [
  body("otp").notEmpty().withMessage("Please Enter Otp"),
];

module.exports = { otpValidation };