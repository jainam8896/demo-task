const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Token = require("../models/Token");
const CustomError = require("../utils/errors/CustomError");

const tokenAuth = async (req, res, next) => {
  let token;
  const { authorization } = req.headers;
  if (authorization && authorization.startsWith("Bearer")) {
    try {
      token = authorization.split(" ")[1];
      if (!token) {
        return next(new CustomError("Unauthorized User, No Token", 404));
      }
      const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
      console.log("Token", token);
      
      const user = await User.findById({ _id });
      if (!user) {
        return next(new CustomError("Unauthorized User, No user Found", 401));
      }

      const tokenData = await Token.findOne({
        userId: user._id,
        token: token,
        type: "2FA_TOKEN",
      });
      console.log("Token Data:- ", tokenData);

      if (!tokenData) {
        return next(new CustomError("Session Expire", 401));
      }
      req.token = tokenData;
      req.user = user;
      console.log("User", req.user);
      console.log("Token", req.token);
      next();
    } catch (error) {
      return next(new CustomError("Unauthorized User, No Access", 500));
    }
  }
};
module.exports = tokenAuth;

