function _responseHandler(req, res, next) {
  res.success = function _success(message, data = {}, statusText, status) {
    return res.status(status).json({
      statusText: statusText,
      message: message,
      data: data,
    });
  };
  next();
}

module.exports = _responseHandler;
